# Online Admins – PostgreSQL-Version

Diese Version ist für einen Node.js-Webhost mit PostgreSQL vorbereitet. Alle Spieler,
Statusänderungen und Berechtigungen liegen in der gemeinsamen PostgreSQL-Datenbank.

## Render: kostenloser Testbetrieb

1. Projekt in ein **privates GitHub-Repository** hochladen.
2. Auf Render einen **Web Service** aus diesem Repository erstellen.
3. Build Command:
   `npm install`
4. Start Command:
   `npm start`
5. Node-Version 20 oder neuer verwenden.
6. Eine PostgreSQL-Datenbank verbinden und deren `DATABASE_URL` als Environment Variable
   im Web Service setzen.
7. Zusätzlich setzen:
   `OWNER_PASSWORD` = ein neues, starkes Owner-Passwort
   `ADMIN_PASSWORD` = ein neues, starkes Admin-Passwort
8. `NODE_ENV=production` setzen.

## Datenbank

Die App legt beim ersten Start automatisch die Tabellen `settings`, `players` und `sessions`
an und legt die fünf Demo-Spieler an, wenn noch keine Spieler vorhanden sind.

## Sicherheit

Passwörter werden serverseitig mit scrypt gehasht. Die geheimen Passwörter werden nicht
an das Browser-JavaScript ausgeliefert.

**Wichtig:** Die alten Passwörter aus der ursprünglichen Demo nicht weiterverwenden.

## Dauerhaft kostenlos

Der Webhost und die Datenbank müssen jeweils einen kostenlosen, dauerhaft verfügbaren
Tarif anbieten. Falls ein Anbieter seinen kostenlosen PostgreSQL-Tarif zeitlich begrenzt
oder das Projekt schlafen legt, ist die Website zwar technisch kompatibel, aber nicht
dauerhaft kostenlos. Die Datenbank sollte außerdem persistent sein.

## Lokal starten

Node.js 20+ installieren, dann:

```bash
npm install
```

Umgebungsvariablen setzen:

```text
DATABASE_URL=postgresql://...
OWNER_PASSWORD=dein-owner-passwort
ADMIN_PASSWORD=dein-admin-passwort
```

Danach:

```bash
npm start
```

und `http://localhost:3000` öffnen.


## Owner-Berechtigungen

Der Owner darf:
- das Admin-Panel benutzen,
- Spieler hinzufügen/entfernen,
- einzelne Spieler On/Off schalten,
- Admin-Berechtigungen und Passwörter verwalten,
- den Live-Status überwachen.

Die **Massenaktionen** „Alle online“ / „Alle offline“ sind für den Owner deaktiviert.
Das wird sowohl im Frontend als auch serverseitig blockiert.


Die Anmeldung verwendet zusätzlich ein Session-Token im Browser, damit der Owner/Admin auch bei Hosting-Proxies zuverlässig als angemeldet erkannt wird. Das Token wird nur in der aktuellen Browser-Session gespeichert.
