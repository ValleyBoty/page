let pendingBulkStatus=null, statusFilter='all';
async function renderOwnerStatusOverview(){
  // Massenaktionen sind bewusst nicht erlaubt; der Owner darf aber den Live-Status überwachen.
  const bulkBox=document.querySelector('.owner-bulk');
  if(bulkBox) bulkBox.hidden=true;
  const panel=document.querySelector('#ownerDialog'), history=document.querySelector('#ownerHistory');
  if(!panel.classList.contains('open') || document.querySelector('#ownerSettings').hidden)return;
  try{
    const data=await api('/api/owner/overview');
    document.querySelector('#dashboardPlayers').textContent=data.players.length;
    document.querySelector('#dashboardOnline').textContent=data.players.filter(p=>p.online).length;
    document.querySelector('#dashboardAdmins').textContent=data.players.filter(p=>p.admin).length;
    const visible=data.players.filter(p=>statusFilter==='all'||(statusFilter==='online'&&p.online)||(statusFilter==='offline'&&!p.online));
    history.innerHTML=`<h3>Live-Status aller Spieler <small>(${visible.length})</small></h3>`+visible.map(p=>{
      const seconds=Math.max(0,Math.floor((Date.now()-new Date(p.statusChangedAt).getTime())/1000));
      return `<div class="history-item"><span class="history-state ${p.online?'':'offline'}">&bull; ${p.online?'ONLINE':'OFFLINE'}</span><b>${escapeHtml(p.name)}</b><span>seit ${seconds}s &middot; ${new Date(p.statusChangedAt).toLocaleTimeString('de-DE')}</span></div>`;
    }).join('');
  }catch(_){}
}
function selectAllStatus(online){
  const password=document.querySelector('#bulkStatusPassword'),error=document.querySelector('#bulkStatusError');
  if(!password.value){error.textContent='Bitte zuerst das Owner-Passwort eingeben.';return;}
  pendingBulkStatus=online;
  error.textContent=`Auswahl gespeichert: Alle werden ${online?'online':'offline'} gesetzt.`;
  error.style.color='#76e9c8';
  document.querySelector('#allOnline').classList.toggle('selected',online);
  document.querySelector('#allOffline').classList.toggle('selected',!online);
}
async function applyPendingBulkStatus(){
  if(!pendingBulkStatus)return;
  try{
    await api('/api/owner/bulk-status',{method:'POST',body:JSON.stringify({online:pendingBulkStatus,password:document.querySelector('#bulkStatusPassword').value})});
    pendingBulkStatus=null;
    document.querySelector('#bulkStatusPassword').value='';
    document.querySelector('#bulkStatusError').textContent='';
    document.querySelector('#allOnline').classList.remove('selected');
    document.querySelector('#allOffline').classList.remove('selected');
    await refresh(); await renderOwnerStatusOverview();
  }catch(e){document.querySelector('#bulkStatusError').textContent=e.message;document.querySelector('#bulkStatusError').style.color='';}
}
document.querySelector('#allOnline').onclick=()=>selectAllStatus(true);
document.querySelector('#allOffline').onclick=()=>selectAllStatus(false);
document.querySelectorAll('[data-status-filter]').forEach(button=>button.onclick=()=>{
  statusFilter=button.dataset.statusFilter;
  document.querySelectorAll('[data-status-filter]').forEach(item=>item.classList.toggle('active',item===button));
  renderOwnerStatusOverview();
});
document.querySelector('#ownerForm').addEventListener('submit',()=>applyPendingBulkStatus(),true);
setInterval(()=>{
  const clock=document.querySelector('#ownerClock');
  if(clock)clock.textContent=new Date().toLocaleTimeString('de-DE');
  renderOwnerStatusOverview();
},1000);
