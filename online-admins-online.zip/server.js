const express = require('express');
const { Pool } = require('pg');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);

if (!process.env.DATABASE_URL) {
  console.warn('DATABASE_URL fehlt. Für Online-Betrieb bitte eine PostgreSQL-Datenbank verbinden.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

const q = (text, params=[]) => pool.query(text, params);

async function initDb() {
  await q(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS players (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      handle TEXT NOT NULL,
      password_hash TEXT,
      online BOOLEAN NOT NULL DEFAULT TRUE,
      status_changed_at TIMESTAMPTZ NOT NULL,
      admin BOOLEAN NOT NULL DEFAULT FALSE
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      role TEXT NOT NULL,
      expires_at BIGINT NOT NULL
    );
  `);

  if (!(await q(`SELECT 1 FROM settings WHERE key='owner_password'`)).rowCount) {
    await q(`INSERT INTO settings(key,value) VALUES('owner_password',$1)`,
      [hashPassword(process.env.OWNER_PASSWORD || 'change-me-now')]);
  }
  if (!(await q(`SELECT 1 FROM settings WHERE key='admin_password'`)).rowCount) {
    await q(`INSERT INTO settings(key,value) VALUES('admin_password',$1)`,
      [hashPassword(process.env.ADMIN_PASSWORD || 'change-me-now')]);
  }

  const count = Number((await q(`SELECT COUNT(*) AS n FROM players`)).rows[0].n);
  if (count === 0) {
    const initial = [
      ['LucasKremer','lucas_kremer',true],
      ['BlockBard','block_bard',true],
      ['Maya','maya_builds',false],
      ['PixelPilot','pixelpilot',true],
      ['NoobNinja','noob_ninja',false]
    ];
    for (const [name,handle,online] of initial) {
      await q(
        `INSERT INTO players(name,handle,online,status_changed_at) VALUES($1,$2,$3,NOW())`,
        [name,handle,online]
      );
    }
  }
}

function hashPassword(password, salt=crypto.randomBytes(16).toString('hex')) {
  return `${salt}:${crypto.scryptSync(String(password), salt, 64).toString('hex')}`;
}
function verifyPassword(password, stored) {
  if (!stored) return false;
  const [salt,key] = stored.split(':');
  if (!salt || !key) return false;
  const candidate = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(key, 'hex');
  return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
}
async function getSetting(key) {
  const r = await q(`SELECT value FROM settings WHERE key=$1`, [key]);
  return r.rows[0]?.value;
}
async function setSetting(key,value) {
  await q(`
    INSERT INTO settings(key,value) VALUES($1,$2)
    ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value
  `, [key,value]);
}
function tokenHash(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}
async function createSession(role) {
  const token = crypto.randomBytes(32).toString('hex');
  await q(
    `INSERT INTO sessions(token_hash,role,expires_at) VALUES($1,$2,$3)`,
    [tokenHash(token), role, Date.now()+1000*60*60*12]
  );
  return token;
}
async function currentRole(req) {
  const bearer = req.headers.authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  const raw = bearer || req.headers.cookie?.match(/(?:^|;\s*)session=([^;]+)/)?.[1];
  if (!raw) return null;
  const r = await q(`SELECT role,expires_at FROM sessions WHERE token_hash=$1`, [tokenHash(raw)]);
  if (!r.rowCount) return null;
  if (Number(r.rows[0].expires_at) < Date.now()) {
    await q(`DELETE FROM sessions WHERE token_hash=$1`, [tokenHash(raw)]);
    return null;
  }
  return r.rows[0].role;
}
function requireRole(role) {
  return async (req,res,next) => {
    try {
      if (await currentRole(req) !== role) return res.status(401).json({error:'Nicht autorisiert.'});
      next();
    } catch (e) { next(e); }
  };
}
function requireAdmin(req,res,next) {
  (async()=>{
    const role = await currentRole(req);
    if (role !== 'admin' && role !== 'owner') return res.status(401).json({error:'Admin-Anmeldung erforderlich.'});
    req.role=role; next();
  })().catch(next);
}
function setSessionCookie(res,token) {
  res.setHeader('Set-Cookie',
    `session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200${process.env.NODE_ENV==='production'?'; Secure':''}`);
}
function clearSessionCookie(res) {
  res.setHeader('Set-Cookie','session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
}
function playerRow(r) {
  return {
    id:r.id, name:r.name, handle:r.handle, online:Boolean(r.online),
    statusChangedAt:r.status_changed_at, admin:Boolean(r.admin)
  };
}
async function getPlayers() {
  const r=await q(`
    SELECT id,name,handle,online,status_changed_at,admin
    FROM players ORDER BY id
  `);
  return r.rows.map(playerRow);
}

app.use(express.json({limit:'32kb'}));
app.use(express.static(__dirname));

app.get('/api/players', async (req,res,next)=>{
  try {
    const role=await currentRole(req);
    res.json({players:await getPlayers(),isAdmin:role==='admin'||role==='owner',isOwner:role==='owner'});
  } catch(e){next(e);}
});

app.post('/api/auth/admin', async (req,res,next)=>{
  try {
    const password=String(req.body.password||'');
    let ok=verifyPassword(password,await getSetting('admin_password'));
    if (!ok) {
      const r=await q(`SELECT password_hash FROM players WHERE admin=TRUE AND password_hash IS NOT NULL`);
      ok=r.rows.some(p=>verifyPassword(password,p.password_hash));
    }
    if (!ok) return res.status(403).json({error:'Passwort ist nicht korrekt.'});
    const token=await createSession('admin');
    setSessionCookie(res,token);
    res.json({ok:true,role:'admin',token});
  } catch(e){next(e);}
});

app.post('/api/auth/owner', async (req,res,next)=>{
  try {
    if (!verifyPassword(String(req.body.password||''),await getSetting('owner_password')))
      return res.status(403).json({error:'Owner-Passwort ist nicht korrekt.'});
    const token=await createSession('owner');
    setSessionCookie(res,token);
    res.json({ok:true,role:'owner',token});
  } catch(e){next(e);}
});

app.post('/api/auth/logout', async (req,res,next)=>{
  try {
    const raw=req.headers.cookie?.match(/(?:^|;\s*)session=([^;]+)/)?.[1];
    if(raw) await q(`DELETE FROM sessions WHERE token_hash=$1`,[tokenHash(raw)]);
    clearSessionCookie(res); res.json({ok:true});
  } catch(e){next(e);}
});

app.post('/api/players', requireAdmin, async (req,res,next)=>{
  try {
    const name=String(req.body.name||'').trim();
    const handle=String(req.body.handle||'').trim() || name.toLowerCase().replace(/\s+/g,'_');
    if(!name)return res.status(400).json({error:'Name fehlt.'});
    const password=String(req.body.password||'');
    const hash=password?hashPassword(password):null;
    const r=await q(`
      INSERT INTO players(name,handle,password_hash,online,status_changed_at)
      VALUES($1,$2,$3,$4,NOW()) RETURNING id
    `,[name,handle,hash,req.body.online!==false]);
    res.json({id:r.rows[0].id});
  } catch(e){next(e);}
});

app.delete('/api/players', requireAdmin, async (req,res,next)=>{
  try { await q(`DELETE FROM players`); res.json({ok:true}); } catch(e){next(e);}
});

app.delete('/api/players/:id', requireAdmin, async (req,res,next)=>{
  try {
    const r=await q(`DELETE FROM players WHERE id=$1`,[Number(req.params.id)]);
    if(!r.rowCount)return res.status(404).json({error:'Spieler nicht gefunden.'});
    res.json({ok:true});
  } catch(e){next(e);}
});

app.post('/api/players/:id/status', async (req,res,next)=>{
  try {
    const r=await q(`SELECT * FROM players WHERE id=$1`,[Number(req.params.id)]);
    if(!r.rowCount)return res.status(404).json({error:'Spieler nicht gefunden.'});
    const p=r.rows[0], role=await currentRole(req);
    const authorized=role==='admin'||role==='owner' ||
      (p.password_hash && verifyPassword(String(req.body.password||''),p.password_hash));
    if(!authorized)return res.status(403).json({error:'Status-Passwort ist falsch.'});
    await q(`UPDATE players SET online=$1,status_changed_at=NOW() WHERE id=$2`,
      [Boolean(req.body.online),p.id]);
    res.json({ok:true});
  } catch(e){next(e);}
});

app.get('/api/owner/settings', requireRole('owner'), async (req,res,next)=>{
  try { res.json({players:await getPlayers()}); } catch(e){next(e);}
});
app.get('/api/owner/overview', requireRole('owner'), async (req,res,next)=>{
  try { res.json({players:await getPlayers()}); } catch(e){next(e);}
});

app.post('/api/owner/bulk-status', requireRole('owner'), async (req,res)=>{
  return res.status(403).json({error:'Massenaktionen sind für den Owner deaktiviert.'});
});

app.put('/api/owner/settings', requireRole('owner'), async (req,res,next)=>{
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    if(req.body.ownerPassword)
      await client.query(`
        INSERT INTO settings(key,value) VALUES('owner_password',$1)
        ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value
      `,[hashPassword(String(req.body.ownerPassword))]);
    if(req.body.adminPassword)
      await client.query(`
        INSERT INTO settings(key,value) VALUES('admin_password',$1)
        ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value
      `,[hashPassword(String(req.body.adminPassword))]);
    for(const x of (req.body.playerPasswords||[])) {
      if(x.password) await client.query(`UPDATE players SET password_hash=$1 WHERE id=$2`,
        [hashPassword(String(x.password)),Number(x.id)]);
    }
    for(const x of (req.body.admins||[])) {
      await client.query(`UPDATE players SET admin=$1 WHERE id=$2`,[Boolean(x.admin),Number(x.id)]);
    }
    await client.query('COMMIT');
    res.json({ok:true});
  } catch(e) {
    await client.query('ROLLBACK'); next(e);
  } finally { client.release(); }
});

app.use((err,req,res,next)=>{
  console.error(err);
  if(res.headersSent)return next(err);
  res.status(500).json({error:'Serverfehler. Bitte später erneut versuchen.'});
});

app.use((req,res)=>{
  if(req.path.startsWith('/api/')) return res.status(404).json({error:'API-Endpunkt nicht gefunden.'});
  res.sendFile(path.join(__dirname,'index.html'));
});

initDb()
  .then(()=>app.listen(PORT,()=>console.log(`Online Admins läuft auf Port ${PORT}`)))
  .catch(err=>{console.error('Datenbank konnte nicht initialisiert werden:',err);process.exit(1);});
