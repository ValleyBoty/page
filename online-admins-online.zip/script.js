const palette=["#7ed9d1","#b19af9","#ffad87","#8ebcf3","#f5ce68","#f193c7"];
let isAdmin=false, isOwner=false, deniedTimer, pendingStatus=null, ownerAuthenticated=false, players=[];
const list=document.querySelector('#playerList'),dialog=document.querySelector('#passwordDialog'),denied=document.querySelector('#accessDenied'),ownerDialog=document.querySelector('#ownerDialog');

async function api(url, options={}) {
  const token=sessionStorage.getItem('onlineAdminsSession');
  const auth=token?{Authorization:`Bearer ${token}`}:{};
  const res=await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json',...auth,...(options.headers||{})},...options});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error||'Anfrage fehlgeschlagen');
  return data;
}
function updateAdminControls(){
  document.querySelectorAll('.actions,.add-form').forEach(el=>el.classList.toggle('admin-locked',!isAdmin));
}
function render(){
  const avatars=document.querySelector('#avatarToggle').checked;
  list.innerHTML='';
  players.forEach((p,i)=>{
    const el=document.querySelector('#playerTemplate').content.firstElementChild.cloneNode(true);
    const avatar=el.querySelector('.avatar'), presence=el.querySelector('.presence'), remove=el.querySelector('.remove');
    avatar.dataset.initial=p.name[0].toUpperCase();
    avatar.style.background=palette[i%palette.length];
    avatar.style.display=avatars?'grid':'none';
    el.querySelector('.number').textContent=String(i+1).padStart(2,'0');
    el.querySelector('.display-name').textContent=p.name;
    el.querySelector('.handle').textContent='@'+p.handle;
    presence.textContent=p.online?'online':'offline';
    presence.classList.toggle('offline',!p.online);
    presence.disabled=Boolean(p.coolingDown);
    presence.onclick=()=>changeStatus(i);
    el.querySelector('.role').classList.toggle('show',Boolean(p.admin));
    el.querySelector('.du').classList.toggle('show',p.isMe===true);
    remove.onclick=()=>{ if(!isAdmin){openAdminDialog();return;} removePlayer(p.id); };
    list.append(el);
  });
  document.querySelector('#serverCount').textContent=players.length;
  document.querySelector('#playerText').textContent=`${players.length} Spieler`;
  updateAdminControls();
  document.querySelector('#adminOnlineCount').textContent=players.filter(p=>p.online).length;
  document.querySelector('#adminPlayerCount').textContent=players.length;
}
async function refresh(){
  const data=await api('/api/players');
  players=data.players;
  isAdmin=Boolean(data.isAdmin); isOwner=Boolean(data.isOwner);
  document.querySelector('#adminPanel').classList.toggle('inactive',!isAdmin);
  document.querySelector('#adminState').textContent=isOwner?'Owner-Modus aktiv':(isAdmin?'Admin-Modus aktiv':'Admin-Modus gesperrt');
  document.querySelector('#adminSession').textContent=isAdmin?'AKTIV':'GESPERRT';
  document.querySelector('#logout').textContent=isAdmin?(isOwner?'Owner abmelden':'Admin abmelden'):'Admin anmelden';
  render();
}
function openDialog(){
  document.querySelector('#adminPassword').value='';
  document.querySelector('#passwordError').textContent='';
  dialog.classList.add('open');
  document.querySelector('#adminPassword').focus();
}
function openAdminDialog(){
  pendingStatus=null;
  document.querySelector('#dialogEyebrow').textContent='Admin-Berechtigung';
  document.querySelector('#dialogTitle').textContent='Admin anmelden';
  document.querySelector('#passwordLabel').textContent='Admin-Status-Passwort';
  document.querySelector('#passwordSubmit').textContent='Admin-Modus aktivieren';
  openDialog();
}
function openStatusDialog(index){
  pendingStatus=index;
  document.querySelector('#dialogEyebrow').textContent='Status-Berechtigung';
  document.querySelector('#dialogTitle').textContent='Status ändern';
  document.querySelector('#passwordLabel').textContent='Eigenes Status-Passwort eingeben';
  document.querySelector('#passwordSubmit').textContent='Status bestätigen';
  openDialog();
}
function closeDialog(){dialog.classList.remove('open');}
function showDenied(message='Status-Passwort ist falsch.'){
  clearTimeout(deniedTimer);
  denied.querySelector('small').textContent=message;
  denied.classList.remove('show'); void denied.offsetWidth; denied.classList.add('show');
  deniedTimer=setTimeout(()=>denied.classList.remove('show'),5000);
}
async function toggleStatus(index){
  const p=players[index];
  p.coolingDown=true; render();
  try { await api(`/api/players/${p.id}/status`,{method:'POST',body:JSON.stringify({online:!p.online})}); }
  catch(e){ showDenied(e.message); }
  await refresh();
}
function changeStatus(index){ if(isAdmin) toggleStatus(index); else openStatusDialog(index); }

async function removePlayer(id){
  try { await api(`/api/players/${id}`,{method:'DELETE'}); await refresh(); }
  catch(e){ showDenied(e.message); }
}
document.querySelector('#simulate').onclick=async()=>{
  if(!isAdmin){openAdminDialog();return;}
  const n=players.length+1;
  try { await api('/api/players',{method:'POST',body:JSON.stringify({name:`Spieler${n}`,handle:`new_player_${n}`,online:true})}); await refresh(); }
  catch(e){showDenied(e.message);}
};
document.querySelector('#removeLast').onclick=async()=>{
  if(!isAdmin){openAdminDialog();return;}
  if(!players.length)return;
  await removePlayer(players[players.length-1].id);
};
document.querySelector('#removeAll').onclick=async()=>{
  if(!isAdmin){openAdminDialog();return;}
  if(!confirm('Wirklich alle Spieler entfernen?'))return;
  try { await api('/api/players',{method:'DELETE'}); await refresh(); } catch(e){showDenied(e.message);}
};
document.querySelector('#avatarToggle').onchange=render;
document.querySelector('#logout').onclick=async()=>{
  if(isAdmin){await api('/api/auth/logout',{method:'POST'}); sessionStorage.removeItem('onlineAdminsSession'); isAdmin=false; isOwner=false; await refresh();} else openAdminDialog();
};
document.querySelector('#addForm').onsubmit=async e=>{
  e.preventDefault();
  if(!isAdmin){openAdminDialog();return;}
  const name=document.querySelector('#discordName').value.trim();
  const handle=document.querySelector('#robloxName').value.trim()||name.toLowerCase().replaceAll(' ','_');
  const password=document.querySelector('#customStatus').value.trim();
  if(!name)return;
  try {
    await api('/api/players',{method:'POST',body:JSON.stringify({name,handle,password,online:document.querySelector('#online').checked})});
    e.target.reset(); document.querySelector('#online').checked=true; await refresh();
  } catch(e){showDenied(e.message);}
};
document.querySelector('#addForm').onclick=()=>{if(!isAdmin)openAdminDialog()};
document.querySelector('#closeDialog').onclick=closeDialog;
dialog.onclick=e=>{if(e.target===dialog)closeDialog()};
document.querySelector('#passwordForm').onsubmit=async e=>{
  e.preventDefault();
  const value=document.querySelector('#adminPassword').value;
  try{
    if(pendingStatus!==null){
      const p=players[pendingStatus];
      await api(`/api/players/${p.id}/status`,{method:'POST',body:JSON.stringify({online:!p.online,password:value})});
      closeDialog(); pendingStatus=null; await refresh(); return;
    }
    const login=await api('/api/auth/admin',{method:'POST',body:JSON.stringify({password:value})});
    if(login.token) sessionStorage.setItem('onlineAdminsSession',login.token);
    isAdmin=true; isOwner=login.role==='owner';
    closeDialog(); await refresh();
  }catch(e){closeDialog();showDenied(e.message);}
};

async function openOwner(){
  ownerAuthenticated=false;
  document.querySelector('#ownerLogin').hidden=false;
  document.querySelector('#ownerSettings').hidden=true;
  document.querySelector('#ownerPassword').value='';
  document.querySelector('#ownerError').textContent='';
  ownerDialog.classList.add('open');
  document.querySelector('#ownerPassword').focus();
}
function closeOwner(){ownerDialog.classList.remove('open');}
async function showOwnerSettings(){
  const data=await api('/api/owner/settings');
  document.querySelector('#ownerLogin').hidden=true;
  document.querySelector('#ownerSettings').hidden=false;
  document.querySelector('#ownerPasswordSetting').value='';
  document.querySelector('#adminPasswordSetting').value='';
  const c=document.querySelector('#ownerPlayers');
  c.innerHTML='<label>Spieler-Berechtigungen</label>';
  data.players.forEach((p,i)=>c.insertAdjacentHTML('beforeend',`<div class="owner-player"><b>${escapeHtml(p.name)}</b><label>Neues Status-Passwort (leer = unverändert)</label><input data-player-password="${p.id}" value="" placeholder="Passwort setzen/ändern" /><label class="admin-checkbox"><input type="checkbox" data-player-admin="${p.id}" ${p.admin?'checked':''}/> Als Admin festlegen</label></div>`));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
document.querySelector('#ownerTrigger').onclick=openOwner;
document.querySelector('#closeOwner').onclick=closeOwner;
ownerDialog.onclick=e=>{if(e.target===ownerDialog)closeOwner()};
document.querySelector('#ownerForm').onsubmit=async e=>{
  e.preventDefault();
  try{
    if(!ownerAuthenticated){
      const login=await api('/api/auth/owner',{method:'POST',body:JSON.stringify({password:document.querySelector('#ownerPassword').value})});
      if(login.token) sessionStorage.setItem('onlineAdminsSession',login.token);
      ownerAuthenticated=true; isAdmin=true; isOwner=true;
      await refresh(); await showOwnerSettings(); return;
    }
    const playerUpdates=[];
    document.querySelectorAll('[data-player-password]').forEach(x=>{if(x.value.trim())playerUpdates.push({id:Number(x.dataset.playerPassword),password:x.value.trim()});});
    const admins=[];
    document.querySelectorAll('[data-player-admin]').forEach(x=>admins.push({id:Number(x.dataset.playerAdmin),admin:x.checked}));
    await api('/api/owner/settings',{method:'PUT',body:JSON.stringify({
      ownerPassword:document.querySelector('#ownerPasswordSetting').value.trim()||undefined,
      adminPassword:document.querySelector('#adminPasswordSetting').value.trim()||undefined,
      playerPasswords:playerUpdates,admins
    })});
    closeOwner(); await refresh();
  }catch(e){document.querySelector('#ownerError').textContent=e.message; showDenied(e.message);}
};
refresh().catch(e=>showDenied(e.message));
setInterval(()=>refresh().catch(()=>{}),5000);
